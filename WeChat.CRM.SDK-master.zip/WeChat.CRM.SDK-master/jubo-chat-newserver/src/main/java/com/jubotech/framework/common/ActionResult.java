package com.jubotech.framework.common;

public class ActionResult {
	
	public static Integer BIZCODE_SUCCESS = 200;
	
	public static String SUCCESS_MSG = "success";
	
}
