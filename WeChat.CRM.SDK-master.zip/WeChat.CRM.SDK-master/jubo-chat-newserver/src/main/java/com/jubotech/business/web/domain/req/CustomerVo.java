package com.jubotech.business.web.domain.req;

import com.jubotech.framework.domain.base.Page;

public class CustomerVo extends Page{
	 
	private String suppliername;

	public String getSuppliername() {
		return suppliername;
	}

	public void setSuppliername(String suppliername) {
		this.suppliername = suppliername;
	}

  
}
