package com.jubotech.framework.netty.common;

public class Constant {
	public static final String ERROR_MSG_ILLEGALDEVICE = "非法设备";
	public static final String ERROR_MSG_DECODFAIL = "解码失败";
	public static final String ERROR_MSG_VERIFYWAY = "认证方式不支持";
	public static final String ERROR_MSG_LOGINFAIL = "账号密码错误";
	public static final String ERROR_MSG_NOTONLINE = "对方不在线";
	public static final String ERROR_MSG_PARAMERROR = "参数传入错误";
}
