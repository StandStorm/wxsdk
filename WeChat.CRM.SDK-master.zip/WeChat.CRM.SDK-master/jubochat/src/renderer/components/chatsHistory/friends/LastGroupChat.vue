<template>
  <div class="goodFriends">
    <div class="tips">功能开发者，敬请期待...</div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.tips {
  color: gray;
}
</style>