<template>
  <div>操作指南</div>
</template>

<script>
export default {
  data () {
    return {

    }
  }

}
</script>

<style lang="scss" scoped>
</style>