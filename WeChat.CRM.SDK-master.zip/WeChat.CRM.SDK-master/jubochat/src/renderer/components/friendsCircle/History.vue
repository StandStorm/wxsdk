<template>
  <div class="friends-circle-history">
    <div class="title"></div>
    <div class="circle-content flex-center">测试版本，功能暂不开放！</div>
    <div class="bottom"></div>
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  }

}
</script>

<style lang="scss" scoped>
.friends-circle-history {
  height: 100%;
  width: 100%;
  .circle-content {
    height: 90%;
  }
}
</style>