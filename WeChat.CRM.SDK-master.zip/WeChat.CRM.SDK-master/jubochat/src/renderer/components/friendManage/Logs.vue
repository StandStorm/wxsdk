<template>
  <div class="">
    <div class="title"></div>
    <div class="content flex-center">测试版本，功能暂不开放！</div>
    <div class="bottom"></div>
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  }

}
</script>

<style lang="scss" scoped>
.content {
  width: 100%;
  height: 90%;
}
</style>