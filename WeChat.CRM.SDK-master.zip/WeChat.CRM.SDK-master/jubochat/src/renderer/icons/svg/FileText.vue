<template>
  <g>
    <path d="M16 0v1024" fill p-id="10355"></path>
    <path d="M32 0v1024" fill p-id="10356"></path>
    <path d="M48 0v1024" fill p-id="10357"></path>
    <path d="M64 0v1024" fill p-id="10358"></path>
    <path d="M80 0v1024" fill p-id="10359"></path>
    <path d="M96 0v1024" fill p-id="10360"></path>
    <path d="M112 0v1024" fill p-id="10361"></path>
    <path d="M128 0v1024" fill p-id="10362"></path>
    <path d="M144 0v1024" fill p-id="10363"></path>
    <path d="M160 0v1024" fill p-id="10364"></path>
    <path d="M176 0v1024" fill p-id="10365"></path>
    <path d="M192 0v1024" fill p-id="10366"></path>
    <path d="M208 0v1024" fill p-id="10367"></path>
    <path d="M224 0v1024" fill p-id="10368"></path>
    <path d="M240 0v1024" fill p-id="10369"></path>
    <path d="M256 0v1024" fill p-id="10370"></path>
    <path d="M272 0v1024" fill p-id="10371"></path>
    <path d="M288 0v1024" fill p-id="10372"></path>
    <path d="M304 0v1024" fill p-id="10373"></path>
    <path d="M320 0v1024" fill p-id="10374"></path>
    <path d="M336 0v1024" fill p-id="10375"></path>
    <path d="M352 0v1024" fill p-id="10376"></path>
    <path d="M368 0v1024" fill p-id="10377"></path>
    <path d="M384 0v1024" fill p-id="10378"></path>
    <path d="M400 0v1024" fill p-id="10379"></path>
    <path d="M416 0v1024" fill p-id="10380"></path>
    <path d="M432 0v1024" fill p-id="10381"></path>
    <path d="M448 0v1024" fill p-id="10382"></path>
    <path d="M464 0v1024" fill p-id="10383"></path>
    <path d="M480 0v1024" fill p-id="10384"></path>
    <path d="M496 0v1024" fill p-id="10385"></path>
    <path d="M512 0v1024" fill p-id="10386"></path>
    <path d="M528 0v1024" fill p-id="10387"></path>
    <path d="M544 0v1024" fill p-id="10388"></path>
    <path d="M560 0v1024" fill p-id="10389"></path>
    <path d="M576 0v1024" fill p-id="10390"></path>
    <path d="M592 0v1024" fill p-id="10391"></path>
    <path d="M608 0v1024" fill p-id="10392"></path>
    <path d="M624 0v1024" fill p-id="10393"></path>
    <path d="M640 0v1024" fill p-id="10394"></path>
    <path d="M656 0v1024" fill p-id="10395"></path>
    <path d="M672 0v1024" fill p-id="10396"></path>
    <path d="M688 0v1024" fill p-id="10397"></path>
    <path d="M704 0v1024" fill p-id="10398"></path>
    <path d="M720 0v1024" fill p-id="10399"></path>
    <path d="M736 0v1024" fill p-id="10400"></path>
    <path d="M752 0v1024" fill p-id="10401"></path>
    <path d="M768 0v1024" fill p-id="10402"></path>
    <path d="M784 0v1024" fill p-id="10403"></path>
    <path d="M800 0v1024" fill p-id="10404"></path>
    <path d="M816 0v1024" fill p-id="10405"></path>
    <path d="M832 0v1024" fill p-id="10406"></path>
    <path d="M848 0v1024" fill p-id="10407"></path>
    <path d="M864 0v1024" fill p-id="10408"></path>
    <path d="M880 0v1024" fill p-id="10409"></path>
    <path d="M896 0v1024" fill p-id="10410"></path>
    <path d="M912 0v1024" fill p-id="10411"></path>
    <path d="M928 0v1024" fill p-id="10412"></path>
    <path d="M944 0v1024" fill p-id="10413"></path>
    <path d="M960 0v1024" fill p-id="10414"></path>
    <path d="M976 0v1024" fill p-id="10415"></path>
    <path d="M992 0v1024" fill p-id="10416"></path>
    <path d="M1008 0v1024M0 16h1024" fill p-id="10417"></path>
    <path d="M0 32h1024" fill p-id="10418"></path>
    <path d="M0 48h1024" fill p-id="10419"></path>
    <path d="M0 64h1024" fill p-id="10420"></path>
    <path d="M0 80h1024" fill p-id="10421"></path>
    <path d="M0 96h1024" fill p-id="10422"></path>
    <path d="M0 112h1024" fill p-id="10423"></path>
    <path d="M0 128h1024" fill p-id="10424"></path>
    <path d="M0 144h1024" fill p-id="10425"></path>
    <path d="M0 160h1024" fill p-id="10426"></path>
    <path d="M0 176h1024" fill p-id="10427"></path>
    <path d="M0 192h1024" fill p-id="10428"></path>
    <path d="M0 208h1024" fill p-id="10429"></path>
    <path d="M0 224h1024" fill p-id="10430"></path>
    <path d="M0 240h1024" fill p-id="10431"></path>
    <path d="M0 256h1024" fill p-id="10432"></path>
    <path d="M0 272h1024" fill p-id="10433"></path>
    <path d="M0 288h1024" fill p-id="10434"></path>
    <path d="M0 304h1024" fill p-id="10435"></path>
    <path d="M0 320h1024" fill p-id="10436"></path>
    <path d="M0 336h1024" fill p-id="10437"></path>
    <path d="M0 352h1024" fill p-id="10438"></path>
    <path d="M0 368h1024" fill p-id="10439"></path>
    <path d="M0 384h1024" fill p-id="10440"></path>
    <path d="M0 400h1024" fill p-id="10441"></path>
    <path d="M0 416h1024" fill p-id="10442"></path>
    <path d="M0 432h1024" fill p-id="10443"></path>
    <path d="M0 448h1024" fill p-id="10444"></path>
    <path d="M0 464h1024" fill p-id="10445"></path>
    <path d="M0 480h1024" fill p-id="10446"></path>
    <path d="M0 496h1024" fill p-id="10447"></path>
    <path d="M0 512h1024" fill p-id="10448"></path>
    <path d="M0 528h1024" fill p-id="10449"></path>
    <path d="M0 544h1024" fill p-id="10450"></path>
    <path d="M0 560h1024" fill p-id="10451"></path>
    <path d="M0 576h1024" fill p-id="10452"></path>
    <path d="M0 592h1024" fill p-id="10453"></path>
    <path d="M0 608h1024" fill p-id="10454"></path>
    <path d="M0 624h1024" fill p-id="10455"></path>
    <path d="M0 640h1024" fill p-id="10456"></path>
    <path d="M0 656h1024" fill p-id="10457"></path>
    <path d="M0 672h1024" fill p-id="10458"></path>
    <path d="M0 688h1024" fill p-id="10459"></path>
    <path d="M0 704h1024" fill p-id="10460"></path>
    <path d="M0 720h1024" fill p-id="10461"></path>
    <path d="M0 736h1024" fill p-id="10462"></path>
    <path d="M0 752h1024" fill p-id="10463"></path>
    <path d="M0 768h1024" fill p-id="10464"></path>
    <path d="M0 784h1024" fill p-id="10465"></path>
    <path d="M0 800h1024" fill p-id="10466"></path>
    <path d="M0 816h1024" fill p-id="10467"></path>
    <path d="M0 832h1024" fill p-id="10468"></path>
    <path d="M0 848h1024" fill p-id="10469"></path>
    <path d="M0 864h1024" fill p-id="10470"></path>
    <path d="M0 880h1024" fill p-id="10471"></path>
    <path d="M0 896h1024" fill p-id="10472"></path>
    <path d="M0 912h1024" fill p-id="10473"></path>
    <path d="M0 928h1024" fill p-id="10474"></path>
    <path d="M0 944h1024" fill p-id="10475"></path>
    <path d="M0 960h1024" fill p-id="10476"></path>
    <path d="M0 976h1024" fill p-id="10477"></path>
    <path d="M0 992h1024" fill p-id="10478"></path>
    <path d="M0 1008h1024" fill p-id="10479"></path>
    <path
      d="M1024 938.667c0 47.147-38.187 85.333-85.333 85.333H85.334C38.187 1024 0.001 985.813 0.001 938.667V85.334C0.001 38.187 38.188 0.001 85.334 0.001h853.333C985.814 0.001 1024 38.188 1024 85.334v853.333z"
      fill="#70B8E6"
      p-id="10480"
    ></path>
    <path
      d="M362.292 332.895v54.375h-91.875v252.708h-64.583V387.27h-92.292v-54.375h248.75z m86.458 307.084h-74.583l98.75-156.458-93.958-150.625h76.667l54.792 99.792 56.25-99.792h74.167l-93.958 148.125 99.792 158.958h-77.917l-58.333-104.583-61.667 104.583zM907.5 332.895v54.375h-91.875v252.708h-64.583V387.27H658.75v-54.375H907.5z"
      fill="#FFFFFF"
      p-id="10481"
    ></path>
  </g>
</template>
