<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'jbchat',
  data () {
    return {
    }
  },
  created () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">
@import url("./styles/reset.css");
@import url("./styles/globals.scss");
</style>

